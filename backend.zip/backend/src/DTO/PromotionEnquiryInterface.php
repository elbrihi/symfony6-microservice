<?php

interface PromotionEnquiryInterface extends \JsonSerializable
{

}
